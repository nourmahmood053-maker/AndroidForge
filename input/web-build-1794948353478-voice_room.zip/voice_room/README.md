# Voice Room

## طريقة 1: من غير كمبيوتر (GitHub)
1. اعمل حساب على github.com وأنشئ repository جديد.
2. ارفع كل ملفات المجلد ده (pubspec.yaml و lib و tools و .github).
3. افتح تبويب Actions ثم Build APK ثم Run workflow.
4. بعد ما يخلص (5 إلى 10 دقايق) افتح التشغيل ونزّل voiceroom-apk من Artifacts.
5. فك الضغط وثبّت app-release.apk على التلفون.

## طريقة 2: على كمبيوتر فيه Flutter
flutter create --platforms=android --project-name voiceroom --org com.voiceroom .
python3 tools/patch_android.py
flutter pub get
flutter build apk --release
الملف في build/app/outputs/flutter-apk/app-release.apk
