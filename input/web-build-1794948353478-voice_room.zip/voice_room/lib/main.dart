import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_sound/flutter_sound.dart';
import 'package:image_picker/image_picker.dart';
import 'package:nearby_connections/nearby_connections.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:record/record.dart';
import 'package:shared_preferences/shared_preferences.dart';

const serviceId = 'com.voiceroom.app';

class Contact {
  final String name, num;
  Contact(this.name, this.num);
  Map<String, String> toJson() => {'name': name, 'num': num};
}

enum CallState { idle, calling, ringing, inCall }

class Svc extends ChangeNotifier {
  static final Svc i = Svc();
  late SharedPreferences prefs;
  String name = '', code = '', num = '', photo = '';
  List<Contact> contacts = [];
  bool get registered => name.isNotEmpty && code.isNotEmpty;

  final Map<String, List<String>> found = {};
  final Set<String> _outgoing = {};
  CallState state = CallState.idle;
  String? peerId;
  String peerName = '', peerNum = '';
  bool muted = false;
  int seconds = 0;
  Timer? _timer;
  String note = '';

  final AudioRecorder _rec = AudioRecorder();
  final FlutterSoundPlayer _player = FlutterSoundPlayer();
  StreamSubscription<Uint8List>? _sub;

  Future<void> load() async {
    prefs = await SharedPreferences.getInstance();
    name = prefs.getString('name') ?? '';
    code = prefs.getString('code') ?? '';
    num = prefs.getString('num') ?? '';
    photo = prefs.getString('photo') ?? '';
    final raw = prefs.getString('contacts');
    if (raw != null) {
      contacts = (jsonDecode(raw) as List)
          .map((e) => Contact(e['name'], e['num']))
          .toList();
    }
    if (registered) start();
  }

  Future<void> register(String n, String c, File? img) async {
    final r = Random.secure();
    num = List.generate(12, (_) => r.nextInt(10)).join();
    name = n;
    code = c;
    if (img != null) {
      final dir = await getApplicationDocumentsDirectory();
      final saved = await img.copy('${dir.path}/profile.jpg');
      photo = saved.path;
    }
    await prefs.setString('name', name);
    await prefs.setString('code', code);
    await prefs.setString('num', num);
    await prefs.setString('photo', photo);
    notifyListeners();
    start();
  }

  Future<void> addContact(String n, String number) async {
    contacts.add(Contact(n, number));
    await prefs.setString(
        'contacts', jsonEncode(contacts.map((e) => e.toJson()).toList()));
    notifyListeners();
  }

  String nameFor(String number, String fallback) {
    for (final c in contacts) {
      if (c.num == number) return c.name;
    }
    return fallback;
  }

  Future<void> start() async {
    await [
      Permission.microphone,
      Permission.location,
      Permission.bluetoothScan,
      Permission.bluetoothAdvertise,
      Permission.bluetoothConnect,
      Permission.nearbyWifiDevices,
    ].request();
    final id = '$num|$name|$code';
    try {
      await Nearby().stopAdvertising();
      await Nearby().stopDiscovery();
      await Nearby().startAdvertising(id, Strategy.P2P_CLUSTER,
          onConnectionInitiated: _onInit,
          onConnectionResult: _onResult,
          onDisconnected: _onDisc,
          serviceId: serviceId);
      await Nearby().startDiscovery(id, Strategy.P2P_CLUSTER,
          onEndpointFound: (eid, n, s) {
            final p = n.split('|');
            if (p.length >= 3 && p[2] == code) found[eid] = p;
          },
          onEndpointLost: (eid) => found.remove(eid),
          serviceId: serviceId);
    } catch (e) {
      note = 'تعذّر تشغيل الاتصال القريب: $e';
      notifyListeners();
    }
  }

  Future<void> ring(Contact c) async {
    final entry = found.entries
        .where((e) => e.value[0] == c.num)
        .map((e) => e.key)
        .toList();
    if (entry.isEmpty) {
      note = '${c.name} مش في المدى أو على كود مختلف';
      notifyListeners();
      return;
    }
    final eid = entry.first;
    peerId = eid;
    peerName = c.name;
    peerNum = c.num;
    state = CallState.calling;
    notifyListeners();
    _outgoing.add(eid);
    try {
      await Nearby().requestConnection('$num|$name|$code', eid,
          onConnectionInitiated: _onInit,
          onConnectionResult: _onResult,
          onDisconnected: _onDisc);
    } catch (e) {
      _end(send: false, msg: 'فشل الاتصال');
    }
  }

  void _onInit(String id, ConnectionInfo info) {
    if (_outgoing.contains(id)) {
      Nearby().acceptConnection(id,
          onPayLoadRecieved: _onPayload, onPayloadTransferUpdate: (a, b) {});
      return;
    }
    final p = info.endpointName.split('|');
    if (p.length < 3 || p[2] != code || state != CallState.idle) {
      Nearby().rejectConnection(id);
      return;
    }
    peerId = id;
    peerNum = p[0];
    peerName = nameFor(p[0], p[1]);
    state = CallState.ringing;
    notifyListeners();
  }

  void accept() {
    if (peerId == null) return;
    Nearby().acceptConnection(peerId!,
        onPayLoadRecieved: _onPayload, onPayloadTransferUpdate: (a, b) {});
  }

  void reject() {
    if (peerId != null) Nearby().rejectConnection(peerId!);
    _end(send: false);
  }

  void _onResult(String id, Status s) {
    if (id != peerId) return;
    if (s == Status.CONNECTED) {
      state = CallState.inCall;
      seconds = 0;
      _timer = Timer.periodic(const Duration(seconds: 1), (_) {
        seconds++;
        notifyListeners();
      });
      notifyListeners();
      _startAudio();
    } else {
      _end(send: false, msg: 'المكالمة اترفضت');
    }
  }

  void _onDisc(String id) {
    if (id == peerId) _end(send: false);
  }

  void _onPayload(String id, Payload p) {
    if (p.type != PayloadType.BYTES || p.bytes == null) return;
    final b = p.bytes!;
    if (b.isEmpty) return;
    if (b[0] == 1) {
      _player.uint8ListSink?.add(Uint8List.sublistView(b, 1));
    } else if (b[0] == 3) {
      _end(send: false);
    }
  }

  Future<void> _startAudio() async {
    try {
      await _player.openPlayer();
      await _player.startPlayerFromStream(
          codec: Codec.pcm16,
          numChannels: 1,
          sampleRate: 16000,
          interleaved: true,
          bufferSize: 4096);
      final s = await _rec.startStream(const RecordConfig(
          encoder: AudioEncoder.pcm16bits, sampleRate: 16000, numChannels: 1));
      _sub = s.listen((d) {
        if (muted || peerId == null) return;
        final out = Uint8List(d.length + 1)..[0] = 1;
        out.setRange(1, out.length, d);
        Nearby().sendBytesPayload(peerId!, out);
      });
    } catch (e) {
      note = 'مشكلة في الصوت: $e';
      notifyListeners();
    }
  }

  void hangup() => _end(send: true);

  Future<void> _end({required bool send, String msg = ''}) async {
    final id = peerId;
    if (send && id != null) {
      try {
        await Nearby().sendBytesPayload(id, Uint8List.fromList([3]));
      } catch (_) {}
    }
    _timer?.cancel();
    await _sub?.cancel();
    _sub = null;
    try {
      await _rec.stop();
    } catch (_) {}
    try {
      await _player.stopPlayer();
      await _player.closePlayer();
    } catch (_) {}
    if (id != null) {
      _outgoing.remove(id);
      try {
        await Nearby().disconnectFromEndpoint(id);
      } catch (_) {}
    }
    peerId = null;
    muted = false;
    state = CallState.idle;
    note = msg;
    notifyListeners();
  }
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Svc.i.load();
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
          colorSchemeSeed: const Color(0xFF8E0052), useMaterial3: true),
      builder: (c, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: AnimatedBuilder(
          animation: Svc.i,
          builder: (_, __) => Svc.i.state == CallState.idle
              ? child!
              : const CallScreen(),
        ),
      ),
      home: const Root(),
    );
  }
}

class Root extends StatelessWidget {
  const Root({super.key});
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: Svc.i,
        builder: (_, __) =>
            Svc.i.registered ? const Home() : const Setup(),
      );
}

Widget avatar(String name, String photo, double size) {
  final has = photo.isNotEmpty && File(photo).existsSync();
  return CircleAvatar(
    radius: size / 2,
    backgroundColor: const Color(0xFF8E0052),
    backgroundImage: has ? FileImage(File(photo)) : null,
    child: has
        ? null
        : Text(name.isEmpty ? '' : name.trim()[0],
            style: TextStyle(fontSize: size / 2.2, color: Colors.white)),
  );
}

class Setup extends StatefulWidget {
  const Setup({super.key});
  @override
  State<Setup> createState() => _SetupState();
}

class _SetupState extends State<Setup> {
  final n = TextEditingController(), c = TextEditingController();
  File? img;
  String? en, ec;

  Future<void> pick() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (x != null) setState(() => img = File(x.path));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(padding: const EdgeInsets.all(24), children: [
          const SizedBox(height: 24),
          const Text('أهلاً بيك',
              style: TextStyle(fontSize: 28, fontWeight: FontWeight.w500)),
          const SizedBox(height: 24),
          Center(
            child: GestureDetector(
              onTap: pick,
              child: CircleAvatar(
                radius: 48,
                backgroundImage: img != null ? FileImage(img!) : null,
                child: img == null ? const Icon(Icons.camera_alt, size: 32) : null,
              ),
            ),
          ),
          const Center(
              child: Padding(
            padding: EdgeInsets.all(8),
            child: Text('صورة البروفايل (اختياري)'),
          )),
          const SizedBox(height: 16),
          TextField(
              controller: n,
              decoration: InputDecoration(
                  labelText: 'الاسم (إجباري)',
                  errorText: en,
                  border: const OutlineInputBorder())),
          const SizedBox(height: 16),
          TextField(
              controller: c,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                  labelText: 'كود الربط',
                  errorText: ec,
                  border: const OutlineInputBorder())),
          const SizedBox(height: 24),
          FilledButton(
            onPressed: () {
              setState(() {
                en = n.text.trim().isEmpty ? 'اكتب اسمك الأول' : null;
                ec = c.text.trim().isEmpty ? 'اكتب كود الربط' : null;
              });
              if (en == null && ec == null) {
                Svc.i.register(n.text.trim(), c.text.trim(), img);
              }
            },
            child: const Padding(
                padding: EdgeInsets.all(12), child: Text('دخول')),
          ),
        ]),
      ),
    );
  }
}

String fmt(String s) => s.replaceAllMapped(RegExp(r'(\d{4})(?=\d)'), (m) => '${m[1]} ');

class Home extends StatelessWidget {
  const Home({super.key});

  void addDialog(BuildContext context) {
    final num = TextEditingController(), nm = TextEditingController();
    String? err;
    showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (ctx, set) => AlertDialog(
          title: const Text('إضافة رقم'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(
                controller: num,
                keyboardType: TextInputType.number,
                maxLength: 12,
                decoration: const InputDecoration(labelText: 'الرقم (12 خانة)')),
            TextField(
                controller: nm,
                decoration: InputDecoration(labelText: 'الاسم', errorText: err)),
          ]),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
            FilledButton(
              onPressed: () {
                final v = num.text.replaceAll(' ', '');
                if (v.length != 12) {
                  set(() => err = 'الرقم لازم يكون 12 رقم');
                } else if (nm.text.trim().isEmpty) {
                  set(() => err = 'اكتب اسم');
                } else {
                  Svc.i.addContact(nm.text.trim(), v);
                  Navigator.pop(ctx);
                }
              },
              child: const Text('حفظ'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = Svc.i;
    return Scaffold(
      appBar: AppBar(title: const Text('غرفة')),
      floatingActionButton: FloatingActionButton(
          onPressed: () => addDialog(context), child: const Icon(Icons.add)),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Row(children: [
          avatar(s.name, s.photo, 48),
          const SizedBox(width: 12),
          Expanded(
              child: Text(s.name,
                  style: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.w500))),
        ]),
        const SizedBox(height: 16),
        Card(
          child: ListTile(
            title: Text(fmt(s.num),
                textDirection: TextDirection.ltr,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 22, letterSpacing: 1)),
            subtitle: const Text('رقمك. دوس للنسخ', textAlign: TextAlign.center),
            onTap: () {
              Clipboard.setData(ClipboardData(text: s.num));
              ScaffoldMessenger.of(context)
                  .showSnackBar(const SnackBar(content: Text('اتنسخ الرقم')));
            },
          ),
        ),
        if (s.note.isNotEmpty)
          Padding(
              padding: const EdgeInsets.all(8),
              child: Text(s.note, textAlign: TextAlign.center)),
        const SizedBox(height: 8),
        if (s.contacts.isEmpty)
          const Padding(
              padding: EdgeInsets.all(32),
              child: Text('لسه مفيش جهات. دوس على الزائد وضيف رقم.',
                  textAlign: TextAlign.center)),
        ...s.contacts.map((c) => Card(
              child: ListTile(
                leading: avatar(c.name, '', 40),
                title: Text(c.name),
                subtitle: Text(fmt(c.num), textDirection: TextDirection.ltr),
                trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                  IconButton(
                      icon: const Icon(Icons.call),
                      tooltip: 'رن',
                      onPressed: () => s.ring(c)),
                  IconButton(
                      icon: const Icon(Icons.message),
                      tooltip: 'مراسلة',
                      onPressed: () => ScaffoldMessenger.of(context)
                          .showSnackBar(const SnackBar(
                              content: Text('المراسلة في النسخة الجاية')))),
                ]),
              ),
            )),
      ]),
    );
  }
}

class CallScreen extends StatelessWidget {
  const CallScreen({super.key});

  String t(int s) =>
      '${(s ~/ 60).toString().padLeft(2, '0')}:${(s % 60).toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    final s = Svc.i;
    final status = switch (s.state) {
      CallState.calling => 'بيرن…',
      CallState.ringing => 'مكالمة واردة',
      _ => t(s.seconds),
    };
    Widget round(IconData i, String l, VoidCallback f, {bool on = false}) =>
        Column(children: [
          InkResponse(
            onTap: f,
            child: CircleAvatar(
                radius: 32,
                backgroundColor: on ? Colors.white : const Color(0xFF121212),
                child: Icon(i, color: on ? Colors.black : Colors.white)),
          ),
          const SizedBox(height: 8),
          Text(l, style: const TextStyle(color: Colors.white70)),
        ]);
    return Scaffold(
      backgroundColor: const Color(0xFF1F1F1F),
      body: SafeArea(
        child: Column(children: [
          const SizedBox(height: 48),
          const Text('الاتصال عبر الغرفة',
              style: TextStyle(color: Colors.white70, fontSize: 18)),
          const SizedBox(height: 24),
          Text(s.peerName,
              style: const TextStyle(color: Colors.white, fontSize: 48)),
          const SizedBox(height: 12),
          Text(fmt(s.peerNum),
              textDirection: TextDirection.ltr,
              style: const TextStyle(color: Colors.white70, fontSize: 20)),
          const SizedBox(height: 8),
          Text(status,
              style: const TextStyle(color: Colors.white54, fontSize: 18)),
          const Spacer(),
          CircleAvatar(
              radius: 70,
              backgroundColor: const Color(0xFF8E0052),
              child: Text(s.peerName.isEmpty ? '' : s.peerName.trim()[0],
                  style: const TextStyle(color: Colors.white, fontSize: 72))),
          const Spacer(),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(24),
            decoration: const BoxDecoration(
                color: Color(0xFF2A2A2A),
                borderRadius: BorderRadius.vertical(top: Radius.circular(32))),
            child: s.state == CallState.ringing
                ? Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                    FloatingActionButton.large(
                        heroTag: 'r',
                        backgroundColor: const Color(0xFFEF6A5E),
                        onPressed: s.reject,
                        child: const Icon(Icons.call_end, color: Colors.black)),
                    FloatingActionButton.large(
                        heroTag: 'a',
                        backgroundColor: Colors.green,
                        onPressed: s.accept,
                        child: const Icon(Icons.call, color: Colors.black)),
                  ])
                : Column(mainAxisSize: MainAxisSize.min, children: [
                    Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      round(s.muted ? Icons.mic_off : Icons.mic, 'كتم', () {
                        s.muted = !s.muted;
                        s.notifyListeners();
                      }, on: s.muted),
                    ]),
                    const SizedBox(height: 24),
                    SizedBox(
                      width: 200,
                      height: 72,
                      child: FilledButton(
                        style: FilledButton.styleFrom(
                            backgroundColor: const Color(0xFFEF6A5E),
                            shape: const StadiumBorder()),
                        onPressed: s.hangup,
                        child: const Icon(Icons.call_end, color: Colors.black),
                      ),
                    ),
                  ]),
          ),
        ]),
      ),
    );
  }
}
